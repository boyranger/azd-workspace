#!/usr/bin/env bash
set -euo pipefail

# DEPRECATED: LiteLLM removed from this template.
# Use `src/zeroclaw/run_local.sh` instead.

echo "litellm artifacts removed — use src/zeroclaw" && exit 0
